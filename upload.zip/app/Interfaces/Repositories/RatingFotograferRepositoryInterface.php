<?php

namespace App\Interfaces\Repositories;

interface RatingFotograferRepositoryInterface {}
