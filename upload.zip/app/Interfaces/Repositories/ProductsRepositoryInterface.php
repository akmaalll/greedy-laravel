<?php

namespace App\Interfaces\Repositories;

interface ProductsRepositoryInterface
{
}