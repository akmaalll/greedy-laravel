<?php

namespace App\Interfaces\Repositories;

interface KategoriRepositoryInterface
{
}
