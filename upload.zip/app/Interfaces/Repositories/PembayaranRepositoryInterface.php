<?php

namespace App\Interfaces\Repositories;

interface PembayaranRepositoryInterface {}
