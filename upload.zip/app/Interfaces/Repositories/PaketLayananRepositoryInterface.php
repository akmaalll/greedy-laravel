<?php

namespace App\Interfaces\Repositories;

interface PaketLayananRepositoryInterface
{
}
