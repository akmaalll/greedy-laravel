<?php

namespace App\Interfaces\Repositories;

interface LayananRepositoryInterface
{
}
