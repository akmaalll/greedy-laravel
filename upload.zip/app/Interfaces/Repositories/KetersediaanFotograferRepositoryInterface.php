<?php

namespace App\Interfaces\Repositories;

interface KetersediaanFotograferRepositoryInterface {}
