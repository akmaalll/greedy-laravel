<?php

namespace App\Interfaces\Repositories;

interface PenugasanFotograferRepositoryInterface {}
