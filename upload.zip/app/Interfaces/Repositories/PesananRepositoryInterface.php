<?php

namespace App\Interfaces\Repositories;

interface PesananRepositoryInterface
{
}
