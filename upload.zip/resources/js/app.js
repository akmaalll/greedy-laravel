import './bootstrap';
import './utils/alert-handler'; // Import Global Alert Handler

/*
  Add custom scripts here
*/
import.meta.glob([
  '../assets/img/**',
  // '../assets/json/**',
  '../assets/vendor/fonts/**'
]);
